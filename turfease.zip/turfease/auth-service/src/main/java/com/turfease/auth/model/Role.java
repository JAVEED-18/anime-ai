package com.turfease.auth.model;

public enum Role {
    USER,
    ADMIN
}