package com.turfease.booking.model;

public enum BookingStatus {
    PENDING,
    CONFIRMED,
    CANCELLED,
    PAID
}