package com.turfease.turf.model;

public enum SportType {
    FOOTBALL, CRICKET, BADMINTON, TENNIS, BASKETBALL
}